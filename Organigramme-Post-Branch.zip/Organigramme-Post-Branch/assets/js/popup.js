function createPopup() {
  // Créer un élément div pour le contenu du popup
  var popupContent = document.createElement("div");
  
  // Ajouter du code HTML au popupContent, avec deux boutons
  popupContent.innerHTML = '<h1>Mon titre de popup</h1><p>Mon contenu de popup</p><button class="btn" id="bouton1">Bouton 1</button><button id="bouton2">Bouton 2</button>';
  
  // Créer un élément div pour le popup
  var popup = document.createElement("div");
  
  // Ajouter une classe CSS au popup
  popup.className = "popup";
  
  // Ajouter le contenu du popup au popup lui-même
  popup.appendChild(popupContent);
  
  // Ajouter le popup à la page
  document.body.appendChild(popup);
  
  // Ajouter un gestionnaire d'événements pour le premier bouton
  var bouton1 = document.getElementById("bouton1");
  bouton1.addEventListener("click", function() {
    // Code à exécuter lors du clic sur le premier bouton
    alert("Bouton 1 cliqué !");
  });
  
  // Ajouter un gestionnaire d'événements pour le deuxième bouton
  var bouton2 = document.getElementById("bouton2");
  bouton2.addEventListener("click", function() {
    // Code à exécuter lors du clic sur le deuxième bouton
    alert("Bouton 2 cliqué !");
  });
}


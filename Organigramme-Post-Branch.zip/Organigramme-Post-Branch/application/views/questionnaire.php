<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="insert" method="post">
        <div>
            <h1>Questionnaire</h1>
            <b>Emp Name : <?php echo $infos['name']; ?></b>
            <input type="hidden" name="empName" value="<?php echo $infos['name'];?>">
            <?php
                $answer_number = 1;
                foreach ($questions as $question) {
                    echo "<p>".$question['question']."</p>";
                    echo "<input type='text' name='A".$answer_number."' required>";
                    $answer_number++;	
                }
            ?>
            
        </div>
        <br>
        <button type="submit">Valider</button>
    </form>
    
</body>
</html>
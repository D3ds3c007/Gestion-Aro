<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/style/style.css">
    <title>Organigramme</title>
</head>
<body>
<h1><?php echo $content['name'];?></h1>
  <div class="details" style="margin-left:800px; margin-top: 150px">
    <details>
        <ul>
          <li>Année de naissance: <?php echo $content['anneeNaissance'];?></li>
          <li>Manager: <?php echo $manager_name['name'];?></li>
          <li>Département: <?php echo $content['dept'];?></li>
          <li>Diplome: <?php echo $content['diplome'];?></li>
          <li>Tel: <?php echo $content['tel'];?></li>
          <li>Date d'intégration: <?php echo $content['dateIntegr'];?></li>
          <li>Post: <?php echo $content['post'];?></li>
          <li>Detail du post<?php echo $content['detail'];?></li>
          <li><?php echo $content['plus'];?></li>
      </ul>
    </details>

    <!-- <button class="btn" style="height:50px; color:black">Supprimer</button>
    <button class="btn"  style="height:50px; color:black">Modifier</button> -->
  </div>
   
</body>
</html>
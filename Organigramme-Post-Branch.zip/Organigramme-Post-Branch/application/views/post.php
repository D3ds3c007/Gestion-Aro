<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choisir Post</title>
</head>
<body>
    <h1>Choose Post</h1>
    <form action="questionnaire" method="get">
        <div><p>Post
                <select name="idPost">
                    <?php
                        foreach ($posts as $post) {
                            echo "<option value='".$post['idPost']."'>".$post['name']."</option>";
                        }
                    ?>
                </select>
                
            </p>
            <button>Next</button>
        </div>
    </form>
    
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/style/main.css">
    <title>Organigramme</title>
</head>
<body>

    <div style="display: flex; float: left;" class="chart-container">

    </div>

    <h1>Insertion Employer</h1>
    <div class="form">
        
        <div >
            <form action="home/next" method="get">
                <label>Nom :</label><br>
                <input type="text" name="name" required><br><br>
                
                <label>Année de Naissance :</label><br>
                <input type="number"  name="anneeNaissance" min=1950 max=2015 required></input><br><br>

                <label>Poste :</label><br>
                <select name="idPost">
                    <?php foreach ($posts as $post) { ?>
                        <option value="<?php echo $post["idPost"];?>"><?php echo $post["name"];?></option>
                    <?php } ?>
                </select>
                <br><br>
                
                <label>Manager :</label><br>
                <select name="idManager">
                <?php foreach ($managers as $manager) { ?>
                        <option value="<?php echo $manager["idEmp"];?>"><?php echo $manager["name"];?></option>
                    <?php } ?>
                </select>
                <br><br>
                
                <label>Département :</label><br>
                <input type="text" name="dept"></input><br> <br>
                
                <label>Diplome :</label><br>
                <input type="text" name="diplome" required></input><br> <br>
                
                <label>Téléphone :</label><br>
                <input type="text" name="tel" required></input><br><br> 
                
                <label>Integration :</label><br>
                <input type="date"  name="dateIntegr" required></input><br> <br>
                
                <input name="btn" class="btn" type="submit" value="Envoyer">
              </form>
              
        </div>
    </div>
   
    <script src="<?php echo base_url()?>assets/js/d3.min.js"></script>
    <!-- <script src="./assets/js/popup.js"></script> -->
    <script>

const cardDefaults = {
    width: 324,
    height: 132,
    borderWidth: 1,
    borderRadius: 5,
    borderColor: { red: 0, green: 0, blue: 0, alpha: 0.1 },
    backgroundColor: { red: 255, green: 255, blue: 255, alpha: 1 },
    connectorLineColor: '#d8d7d7',
    connectorLineWidth: 3,
    dashArray: '',
    expanded: false
};
const nodeImageDefaults = {
    width: 94,
    height: 60,
    centerTopDistance: 0,
    centerLeftDistance: 0,
    cornerShape: 'ROUNDED',
    shadow: false,
    borderWidth: 1,
    borderColor: { red: 0, green: 0, blue: 0, alpha: 0.15 }
};
const nodeIconDefault = { icon: './assets/media/companies-tree.svg', size: 24 };

const templateDefault = (title, afterTitle, share) => {
    // Throw error if there was no title
    if (!title) throw new Error('You have to provide a title!');

    let output = '<div class="tree-chart__card">\n';

    if (title) {
        output += `<div class="tree-chart__card__title">${title}</div>`;
    }
    if (afterTitle) {
        output += `<div class="tree-chart__card__after-title">${afterTitle}</div>\n`;
    }
    if (share) {
        output += `<a href="home/details?idEmp=${share}" class="tree-chart__card__share" >Details</a>\n`;
    }

    output += '</div>';

    return output;
};
var emp = JSON.parse(<?php echo json_encode($content); ?>);
console.log(emp);
// Nodes data
window.data = [];
for(let e of emp)
{
    if(e['idManager']==0)
            e['idManager'] = null;
    var obj = new Object({
        nodeId : e['idEmp'],
        parentNodeId : e['idManager'],
        nodeImage : { url : './assets/media/logo.jpg'},
        template : templateDefault(e['post'],e['name'],e['idEmp'])
    });
    window.data.push(obj);
}
window.data.map((node) => {
    // Set default values to not repeat them in each node
    // Node's default values
    const defaultKeys = {
        width: cardDefaults.width,
        height: cardDefaults.height,
        borderWidth: cardDefaults.borderWidth,
        borderRadius: cardDefaults.borderRadius,
        borderColor: cardDefaults.borderColor,
        backgroundColor: cardDefaults.backgroundColor,
        nodeImage: {
            width: nodeImageDefaults.width,
            height: nodeImageDefaults.height,
            centerTopDistance: nodeImageDefaults.centerTopDistance,
            centerLeftDistance: nodeImageDefaults.centerLeftDistance,
            cornerShape: nodeImageDefaults.cornerShape,
            shadow: nodeImageDefaults.shadow,
            borderWidth: nodeImageDefaults.borderWidth,
            borderColor: nodeImageDefaults.borderColor
        },
        nodeIcon: nodeIconDefault,
        connectorLineColor: cardDefaults.connectorLineColor,
        connectorLineWidth: cardDefaults.connectorLineWidth,
        dashArray: cardDefaults.dashArray,
        expanded: cardDefaults.expanded
    };

    // Set node's root default values
    Object.keys(defaultKeys).map((key) => {
        if (!node[key]) {
            node[key] = defaultKeys[key];
        }
    });

    // Set nodeImage default values
    Object.keys(defaultKeys.nodeImage).map((key) => {
        if (!node.nodeImage[key]) {
            node.nodeImage[key] = defaultKeys.nodeImage[key];
        }
    });

    return node;
});

    </script>
    <script src="<?php echo base_url()?>assets/js/main.js"></script>
</body>
</html>
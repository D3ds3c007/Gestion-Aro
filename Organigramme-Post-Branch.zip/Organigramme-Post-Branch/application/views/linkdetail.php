<?php
	$this->load->view("detail/details");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/style/style.css">
    <title>Organigramme</title>
</head>
<body>

    <!-- <div style="display: flex; float: left;" class="chart-container">

    </div> -->
    <h1>Modifier</h1>
    <div class="form">
        <!-- <div >
            <button onclick="createPopup()">Popup</button>
        </div> -->
        
        <div >
            <form>
               
                <label for="email">Nom :</label><br>
                <input type="email" id="email" name="email"><br><br>
                
                <label for="message">Age :</label><br>
                <input type="number"  name="message"></input><br><br>

                <label for="message">Poste :</label><br>
                <select name="" id="">
                    <option value="">Finance</option>
                    <option value="">Marketign</option>
                </select><br><br>
                <!-- <input  name="message"></input><br>  -->
                
                <label for="message">Manager :</label><br>
                <select name="" id="">
                    <option value="">Manager1</option>
                    <option value="">Manager2</option>
                </select> <br><br>
                
                <label for="message">Département :</label><br>
                <input  name="message"></input><br> <br>
                
                <label for="message">Diplome :</label><br>
                <input  name="message"></input><br> <br>
                
                <label for="message">Téléphone :</label><br>
                <input type="number"  name="message"></input><br><br> 
                
                <label for="message">Integration :</label><br>
                <input type="date"  name="message"></input><br> <br>
                
                <label for="message">Details poste :</label><br>
                <textarea style="border:none; border-radius: 5px; width: 220px;"  name="message"></textarea><br><br>
                
                <input name="btn" class="btn" type="submit" value="Envoyer">
              </form>
              
        </div>
    </div>
    
    <script src="<?php echo base_url()?>assets/js/d3.min.js"></script>
    <!-- <script src="./assets/js/popup.js"></script> -->
    <script src="<?php echo base_url()?>assets/js/data.js"></script>
    <script src="<?php echo base_url()?>assets/js/style.js"></script>
</body>
</html>
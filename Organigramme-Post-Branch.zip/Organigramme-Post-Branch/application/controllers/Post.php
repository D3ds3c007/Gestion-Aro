<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Data');
    }
    
    public function index()
    {
        $data = array();
		$data['posts'] = $this->Data->get_post_with_questions();

        $this->load->view('post', $data);
    }

    public function questionnaire()
    {
        $data = array();
        $data['infos'] = $this->session->userdata('info');
        $data['questions'] = $this->Data->get_questionnaire($data['infos']['idPost']);
        #var_dump($data);
        
        $this->load->view('questionnaire', $data);
    }

    public function insert()
    {
        $this->load->model('Form');

        $data = array();
        $infos = $this->session->userdata('info');
        $data['questions'] = $this->Data->get_questionnaire($infos['idPost']);

        $form_data = $this->input->post(NULL, TRUE);
        $this->db->insert('emp', $infos);
        $id= $this->db->insert_id();
        $this->Form->save_form_data_to_xml($form_data, $id);
       	
    }

}
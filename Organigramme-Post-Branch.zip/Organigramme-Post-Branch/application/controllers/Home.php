<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->model('Data');
		$data = array();
		$data['content'] = $this->Data->getData();
		$data['posts'] = $this->Data->get_post_with_questions();
		$data['managers'] = $this->Data->get_manager();

		$this->load->view('index', $data);
		
	}

	public function test()
	{
		echo 'test';
	}
	
	public function next()
	{

		$data = array();
		$data['name'] = $this->input->get('name');
		$data['anneeNaissance'] = $this->input->get('anneeNaissance');
		$data['idPost'] = $this->input->get('idPost');
		$data['idManager'] = $this->input->get('idManager');
		$data['dept'] = $this->input->get('dept');
		$data['diplome'] = $this->input->get('diplome');
		$data['tel'] = $this->input->get('tel');
		$data['dateIntegr'] = $this->input->get('dateIntegr');

		$this->session->set_userdata('info', $data);

		#$this->load->model('Data');
		#$this->Data->insert_emp($name, $anneeNaissance, $idPost, $idManager, $dept, $diplome, $tel, $dateIntegr);
		redirect('post/questionnaire', 'auto');
	}
	public function details(){
		$this->load->model('Detail');
		// $this->load->view('linkdetail');
		$idEmp = $this->input->get('idEmp');
		$data = array();
		$data['content'] = $this->Detail->get_detail($idEmp);
		$data['manager_name'] = $this->Detail->get_manager_name($idEmp);
		$this->load->view('detail/details',$data);

	}
}

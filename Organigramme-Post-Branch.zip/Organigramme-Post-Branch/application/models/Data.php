<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');

class Data extends CI_Model{

    public function getData(){
        $sql = "select  idEmp,
        name,
        idManager,
        post
from    (select * from CardOrgan
        order by idManager, idEmp) products_sorted,
        (select @pv := 0) initialisation
where   find_in_set(idManager, @pv)
and     length(@pv := concat(@pv, ',', idEmp));";
        $query = $this->db->query($sql);
        return json_encode($query->result_array());
    }

    function insert_emp($name, $anneeNaissance, $idPost, $idManager, $dept, $diplome, $tel, $dateIntegr)
    {
        // set default dept

        $query = $this->db->query("SELECT idManager, dept FROM Emp WHERE idEmp=".$idManager);
        $mng = $query->row_array();

        $id = (int) $mng['idManager'];
        if ($id != 0) {
            $dept = $mng['dept'];
        }

        $sql = "INSERT INTO Emp(name, anneeNaissance, idPost, idManager, dept, diplome, tel, dateIntegr, detailPost) VALUES ('%s',%s,%s,%s,'%s','%s','%s','%s',NULL)";
        $sql_exe = sprintf($sql, $name, $anneeNaissance, $idPost, $idManager, $dept, $diplome, $tel, $dateIntegr);

        $query = $this->db->query($sql_exe);

        return 0;

    }

    function get_post()
    {
        $sql = "SELECT idPost, name, niveau FROM Post";

        $query = $this->db->query($sql);
        $result = $query->result_array();

        return $result;
    }

    function get_post_with_questions()
    {
        $sql = "SELECT idPost, name, niveau FROM Post WHERE idPost IN (SELECT idPost FROM questionnaire)";

        $query = $this->db->query($sql);
        $result = $query->result_array();

        return ($result);
    }

    function get_questionnaire($idPost)
    {
        $sql = "SELECT idPost, question FROM questionnaire WHERE idPost = %s";

        $sql_exe = sprintf($sql, $idPost);

        $query = $this->db->query($sql_exe);
        $result = $query->result_array();

        return $result;
    }
    

    function get_manager()
    {
        $sql = "SELECT idEmp, name FROM Emp";

        $query = $this->db->query($sql);
        $result = $query->result_array();

        return $result;
    }
}
?>
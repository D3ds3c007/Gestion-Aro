<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');

class Detail extends CI_Model{

    // public function getDetail($idemp){
    //     $sql = 'SELECT e.*,p.name from emp e join post p on e.idPost=p.idPost where idEmp='.$idemp;
    //     $query = $this->db->query($sql);
    //     return json_encode($query->result_array());
    // }
    function get_detail($idEmp)
    {
        $sql = "SELECT * FROM Details WHERE idEmp=".$idEmp;
        $query = $this->db->query($sql);
        $result = $query->row_array(); 
        return $result;
    }
    function get_manager_name($idEmp)
    {
        $sql = "SELECT name FROM emp where idEmp= (SELECT idManager from Details where idEmp=".$idEmp.")";
        $query = $this->db->query($sql);
        $result = $query->row_array(); 
        return $result;
    }

}
?>
<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');

class Form extends CI_Model{
 
    
 
    public function save_form_data_to_xml($form_data, $id) {
        // Retrieve the form data
        $formData = $form_data;

        // Create a new SimpleXMLElement object
        $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><form></form>');

        // Loop through the form data and add each key-value pair as an element and its corresponding value as its text content
        $infoTag = $xml->addChild('Informations');
        var_dump($form_data);
        $infoTag->addChild('empName', $form_data['empName']);
        $infoTag->addChild('empId', $id);
        $answerTag = $xml->addChild('Answers');
        foreach ($formData as $key => $value) {
            if(strcmp($key, 'empName')!=0)
            {
                $answerTag->addChild($key, $value);
            }
            #$xml->addChild($key, $value);
        }

        // Convert the SimpleXMLElement object to a string representation of the XML data
        $xmlString = $xml->asXML();

        // Write the string representation to a file
        file_put_contents('assets/data/'.$id.'.xml', $xmlString);
        // Redirect the user back to the form page
        exit();
    

    

}
}

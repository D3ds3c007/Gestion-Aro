--schema
DROP DATABASE gestion;

CREATE DATABASE gestion;

USE gestion;

CREATE TABLE Post (
  idPost INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(30),
  niveau INT,
  detail VARCHAR(255)
);

CREATE TABLE Emp (
  idEmp INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(30),
  anneeNaissance INT NOT NULL,
  idPost INT(11),
  idManager INT(11),
  dept VARCHAR(30),
  diplome VARCHAR(50),
  tel VARCHAR(20),
  dateIntegr DATE,
  detailPost VARCHAR(255),
  CONSTRAINT fk_Post FOREIGN KEY (idPost) REFERENCES Post(idPost),
  CONSTRAINT fk_Manager FOREIGN KEY (idManager) REFERENCES Emp(idEmp)
);

--données de test

--INSERT 
INSERT INTO Post (name, niveau, detail)
VALUES ('Directeur général', 1, 'responsable de la gestion globale de l entreprise et de la prise de décisions stratégiques.');

INSERT INTO Post (name, niveau, detail)
VALUES ('Directeur d usine', 2, 'responsable de la gestion de l usine, y compris la production, la qualité, la maintenance et les opérations quotidiennes.');

INSERT INTO Post (name, niveau, detail)
VALUES ('Responsable de production', 3, 'responsable de la planification de la production, de l optimisation de la productivité et de la gestion des équipes de production.');

INSERT INTO Post (name, niveau, detail)
VALUES ('Superviseur de production', 4, 'responsable de la gestion de l équipe de production, de la formation et de l encadrement des travailleurs.');

INSERT INTO Post (name, niveau, detail)
VALUES ('Ouvrier de production', 5, 'responsable de l exécution des tâches de production, telles que l assemblage, la fabrication et la manutention des matériaux.');

INSERT INTO Post (name, niveau, detail)
VALUES ('Secrétaire', null, 'responsable de la gestion des communications et des tâches administratives.');
       
INSERT INTO Post (name, niveau, detail)
VALUES ('Comptable', null, 'responsable de la gestion des finances et des déclarations fiscales de l entreprise.');
       
INSERT INTO Post (name, niveau, detail)
VALUES ('Sécurité', null, 'responsable de la sécurité des personnes et des biens dans l entreprise et de la prévention des risques.');


--INSERT EMP

INSERT INTO Emp (name, anneeNaissance, idPost, idManager, dept, diplome, tel, dateIntegr, detailPost) VALUES
('Jacky RABEMANANJARA', 1986, 1, NULL, 'Informatique', 'Diplôme en Ingénierie Électrique', '+261 34 21 345 67', '2018-01-01', NULL);

INSERT INTO Emp (name, anneeNaissance, idPost, idManager, dept, diplome, tel, dateIntegr, detailPost) VALUES
('Bao RAKOTONDRANAIVO', 1989, 2, 1, 'Informatique', 'Master en Management des Opérations', '+261 34 87 654 32', '2019-09-01', NULL);

INSERT INTO Emp (name, anneeNaissance, idPost, idManager, dept, diplome, tel, dateIntegr, detailPost) VALUES
('Hery RASOANOMENJANAHARY', 1994, 3, 2, 'Informatique', 'Diplôme en Gestion Financière', '+261 34 76 666 55', '2020-03-05', NULL);

INSERT INTO Emp (name, anneeNaissance, idPost, idManager, dept, diplome, tel, dateIntegr, detailPost) VALUES
('Jean-Luc RAKOTOARISON', 1988, 4, 3, 'Informatique', 'Master en Gestion des Ressources Humaines', '+261 32 45 678 90', '2018-07-01', NULL);

INSERT INTO Emp (name, anneeNaissance, idPost, idManager, dept, diplome, tel, dateIntegr, detailPost) VALUES
('Vero ANDRIANARISOA', 1990, 5, 4, 'Informatique', 'Licence en Informatique', '+261 34 98 765 43', '2019-09-10', NULL);

INSERT INTO Emp (name, anneeNaissance, idPost, idManager, dept, diplome, tel, dateIntegr, detailPost) VALUES
('John ANDRIAMAMPIONONA', 1988, 7, 2, 'Informatique', 'Diplôme en Gestion Comptable', '+261 34 76 543 21', '2019-05-01', NULL);

INSERT INTO Emp (name, anneeNaissance, idPost, idManager, dept, diplome, tel, dateIntegr, detailPost) VALUES
('Tiana RAMANANTSOA', 1994, 2, 1, 'Marketing', 'Master en Marketing Digital', '+261 34 55 321 09', '2020-01-01', NULL);

INSERT INTO Emp (name, anneeNaissance, idPost, idManager, dept, diplome, tel, dateIntegr, detailPost) VALUES
('Mamy RAJAONARISON', 1981, 3, 7, 'Marketing', 'Licence en Ressources Humaines', '+261 34 99 887 77', '2017-11-15', NULL);

INSERT INTO Emp (name, anneeNaissance, idPost, idManager, dept, diplome, tel, dateIntegr, detailPost) VALUES
('Elisa RANDRIANARIVELO', 1998, 4, 8, 'Marketing', 'Licence en Commerce International', '+261 34 54 321 98', '2021-08-01', NULL);

INSERT INTO Emp (name, anneeNaissance, idPost, idManager, dept, diplome, tel, dateIntegr, detailPost) VALUES
('Mireille RALAIMANANA', 1992, 6, 7, 'Marketing', 'Licence en Droit', '+261 33 23 456 78', '2021-02-05', NULL);

INSERT INTO Emp (name, anneeNaissance, idPost, idManager, dept, diplome, tel, dateIntegr, detailPost) VALUES
('Fanny RAZAFIMAHATRATRA', 1995, 8, 7, 'Marketing', 'Master en Marketing Digital', '+261 34 55 321 09', '2020-01-01', NULL);

CREATE OR REPLACE VIEW CardOrgan AS ( SELECT Emp.idEmp, Emp.idManager, Emp.name , Post.name as post FROM Emp JOIN Post ON Emp.idPost=Post.idPost );

CREATE OR REPLACE VIEW Details AS( SELECT Emp.idEmp, Emp.name, Emp.anneeNaissance, Emp.idManager, Emp.dept, Emp.diplome, Emp.tel, Emp.dateIntegr, Post.name as post, Post.detail as detail, Emp.detailPost as plus FROM Emp JOIN Post ON Post.idPost=Emp.idPost ) ;
